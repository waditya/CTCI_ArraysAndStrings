package Master;

public class Entry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EditChecker ec = new EditChecker();
		
		
		boolean case1 = ec.oneEditAway("pale", "ple");
		boolean case2 = ec.oneEditAway("pales", "pale");
		boolean case3 = ec.oneEditAway("pale", "bake");

		System.out.println("pale, ple : "+case1);
		System.out.println("pale, pale : "+case2);
		System.out.println("pale, bake : "+case3);
	}

}
