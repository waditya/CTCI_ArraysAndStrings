package Master;

import java.lang.Math;

public class EditChecker {


public boolean oneEditAway(String first, String second) {
	/*Length Checks*/
	if(Math.abs(first.length() - second.length()) > 1) {
		return false;
	}
	/*Identify shorter and longer strings
	 * s1 is made shorter string and 
	 * s2 is made longer string
	 * */
	
	String s1 = first.length() < second.length()? first:second;
	String s2 = first.length() < second.length()?second:first;
	
	/*We would be iterating over both strings
	 * Declare and initialize 2 index variables 
	 * index1 and index2 */
	int index1 = 0;
	int index2 = 0;
	
	/*A variable - preferably boolean is used to keep track if difference is found
	 * Declare and initialize the boolean variable foundDifference to false*/
	
	boolean foundDifference = false;
	
	/*Iterate over 2 strings till either of then ends*/
	
	while(index2 < s2.length() && index1 <s1.length()) {
		if(s1.charAt(index1)!= s2.charAt(index2)) {
			/*Ensure that this is the first difference found*/
			
			if(foundDifference) {
				return false;
			}
				
			foundDifference = true;		
		
			if(s1.length() == s2.length()) {
				/*On replace move shorter pointer*/
				index1++;
			}
			
		}else {
			index1++; //If matching, move shorter pointer
		
		}
		index2++; //Always move pointer for longer string
		
	
	
	}
	return true;
  }
}
